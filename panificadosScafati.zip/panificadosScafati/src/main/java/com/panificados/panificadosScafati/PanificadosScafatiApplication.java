package com.panificados.panificadosScafati;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PanificadosScafatiApplication {

	public static void main(String[] args) {
		SpringApplication.run(PanificadosScafatiApplication.class, args);
	}

}
